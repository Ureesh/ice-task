/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package icetask1;

import java.util.Scanner;

/**
 *
 * @author urees
 */
public class Reptile extends Animal {
    private double bloodTemp;

    public Reptile() {
        super();
        inputBloodTemp();
    }

    private void inputBloodTemp() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter blood temperature: ");
        bloodTemp = scanner.nextDouble();
    }

    @Override
    public void output() {
        super.output();
        System.out.println("Blood temperature: " + bloodTemp);
    }
    
}
