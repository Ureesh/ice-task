/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package icetask1;

import java.util.Scanner;

/**
 *
 * @author urees
 */
public class Bird extends Animal {
    private int colour;

    public Bird() {
        super();
        inputColor();
    }

    private void inputColor() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter feather colour (1-grey, 2-white, 3-black): ");
        colour = scanner.nextInt();
    }

    @Override
    public void output() {
        super.output();
        System.out.println("Feather colour: " + getColourName());
    }

    private String getColourName() {
        switch (colour) {
            case 1:
                return "Grey";
            case 2:
                return "White";
            case 3:
                return "Black";
            default:
                return "Unknown";
        }
    }
    
}
