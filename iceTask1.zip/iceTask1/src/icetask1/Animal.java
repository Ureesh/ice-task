/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package icetask1;

import java.util.Scanner;

/**
 *
 * @author urees
 */
public class Animal {
    protected int iDtag;
    protected String species;

    public Animal() {
        input();
    }
    
    public void input() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter ID tag: ");
        iDtag = scanner.nextInt();
        System.out.print("Enter species: ");
        species = scanner.next();
    }

    public void output() {
        System.out.println("ID tag: " + iDtag);
        System.out.println("Species: " + species);
    }
    
}
